package com.testing.behaviors;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.testing.model.ZoftModel;

public class DocumentEventHandler {
	 private static Log logger = LogFactory.getLog(DocumentEventHandler.class);

    private PolicyComponent policyComponent;
    private ServiceRegistry serviceRegistry;

    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
        this.serviceRegistry = serviceRegistry;
    }

    public void setPolicyComponent(PolicyComponent policyComponent) {
        this.policyComponent = policyComponent;
    }

    public void registerEventHandlers() {
        policyComponent.bindClassBehaviour(
                NodeServicePolicies.OnCreateNodePolicy.QNAME,
                ContentModel.TYPE_CONTENT,
                new JavaBehaviour(this, "onAddDocument",
                        Behaviour.NotificationFrequency.TRANSACTION_COMMIT));
        
        
      

        policyComponent.bindClassBehaviour(
                NodeServicePolicies.OnUpdateNodePolicy.QNAME,
                ContentModel.TYPE_CONTENT,
                new JavaBehaviour(this, "onUpdateDocument",
                        Behaviour.NotificationFrequency.TRANSACTION_COMMIT));

       /* policyComponent.bindClassBehaviour(
                NodeServicePolicies.OnDeleteNodePolicy.QNAME,
                ContentModel.TYPE_CONTENT,
                new JavaBehaviour(this, "onDeleteDocument",
                        Behaviour.NotificationFrequency.TRANSACTION_COMMIT));*/
        
        
        policyComponent.bindClassBehaviour(
                NodeServicePolicies.OnDeleteNodePolicy.QNAME,
                ZoftModel.TYPE_OFFERLETTER,
                new JavaBehaviour(this, "onDeleteDocument",
                        Behaviour.NotificationFrequency.TRANSACTION_COMMIT));
    }

    public void onAddDocument(ChildAssociationRef parentChildAssocRef) {
        NodeRef parentFolderRef = parentChildAssocRef.getParentRef();
        NodeRef docRef = parentChildAssocRef.getChildRef();

        // Check if node exists, might be moved, or created and deleted in same transaction.
        if (docRef == null || !serviceRegistry.getNodeService().exists(docRef)) {
            // Does not exist, nothing to do
            logger.warn("onAddDocument: A new document was added but removed in same transaction");
            return;
        } else {
            logger.debug("onAddDocument: A new document with ref "+ docRef +"was just created in folder"+parentFolderRef );            
            invokeAction("testingbehavior", "testbehaviouron add document", "Body", docRef);
            //YOu can perform any other step here
            
            /*this.serviceRegistry.getNodeService().getp*/
            
            
        }
    }

    public void onUpdateDocument(NodeRef docNodeRef) {
        // Check if node exists, might be moved, or created and deleted in same transaction.
        if (docNodeRef == null || !serviceRegistry.getNodeService().exists(docNodeRef)) {
            // Does not exist, nothing to do
            logger.warn("onUpdateDocument: A document was updated but removed in same transaction");
            return;
        } else {
            NodeRef parentFolderRef = serviceRegistry.getNodeService().getPrimaryParent(docNodeRef).getParentRef();
            logger.debug("onUpdateDocument: A document with ref"+ docNodeRef +" was just updated in folder " + parentFolderRef);
        }
    }

    public void onDeleteDocument(ChildAssociationRef parentChildAssocRef, boolean isNodeArchived) {
        NodeRef parentFolderRef = parentChildAssocRef.getParentRef();
        NodeRef docRef = parentChildAssocRef.getChildRef();
        logger.debug("onDeleteDocument: A document with ref"+ docRef +" was just deleted in folder"+ parentFolderRef);
        
        sendDeleteMail();
        
    }
    
    
    
    void sendDeleteMail(){
    	//Get smtp connection
    	// send the mail
    }
    
    public void invokeAction(String to, String subject, String bodyText, NodeRef docNodeRef) {
    	logger.debug("Invoking the action from behaviour");
	    boolean executeAsync = true;
	    Map<String, Serializable> aParams = new HashMap<String, Serializable>();
	    aParams.put("to", to);
	    aParams.put("subject", subject);
	    aParams.put("body_text", bodyText);
	    Action a = this.serviceRegistry.getActionService().createAction("send-as-email", aParams);
	    if (a != null) {
	    	this.serviceRegistry.getActionService().executeAction(a, docNodeRef, true, executeAsync);
	    } else {
	       throw new RuntimeException("Could not create send-as-email action");
	    }
	}

}
