package com.testing.webscripts.functionality;

import java.util.HashMap;
import java.util.Map;

import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class FirstExampleWebScript extends DeclarativeWebScript {
	
    protected Map<String, Object> executeImpl(
            WebScriptRequest req, Status status, Cache cache) {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("value1", "Value1Value1Value1Value1Value1Value1Value1");
        model.put("value2", "value2value2value2value2value2value2value2");
        return model;
    }
}


