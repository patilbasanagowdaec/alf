/**
 * 
 */
package com.testing.webscripts.functionality;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ActionService;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * @author bapatil
 *
 */
public class InvokeActionWebScript extends DeclarativeWebScript {
	
	 private static final Log LOGGER = LogFactory.getLog(InvokeActionWebScript.class);
	 NodeService nodeService;
	 FileFolderService fileFolderService;
	 ActionService actionService;
	

	protected Map<String, Object> executeImpl(
           WebScriptRequest req, Status status, Cache cache) {
       Map<String, Object> model = new HashMap<String, Object>();
       
       String reqNodeRefID = req.getParameter("nodeRefid");
       LOGGER.debug("NodeRef recieved from request : " + reqNodeRefID);
       NodeRef docNodeRef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, reqNodeRefID);       
       model.put("value1","invoking the action");       
       invokeAction("patil", "testmail", "This is the body from webscript", docNodeRef);
       return model;
	}
	
	
	public void invokeAction(String to, String subject, String bodyText, NodeRef docNodeRef) {
	    boolean executeAsync = true;
	    Map<String, Serializable> aParams = new HashMap<String, Serializable>();
	    aParams.put("to", to);
	    aParams.put("subject", subject);
	    aParams.put("body_text", bodyText);

	    Action a = this.actionService.createAction("send-as-email", aParams);
	    if (a != null) {
	    	this.actionService.executeAction(a, docNodeRef, true, executeAsync);
	    } else {
	       throw new RuntimeException("Could not create send-as-email action");
	    }
	}
	
	
	public NodeService getNodeService() {
		return nodeService;
	}



	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}



	public FileFolderService getFileFolderService() {
		return fileFolderService;
	}



	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}



	public ActionService getActionService() {
		return actionService;
	}



	public void setActionService(ActionService actionService) {
		this.actionService = actionService;
	}



}
