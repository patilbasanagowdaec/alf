package com.testing.model;

import org.alfresco.service.namespace.QName;

public interface ZoftModel {
	
	
	String ZOFT_MODEL_1_0_URI = "http://www.zoftsolutions.com";
	QName TYPE_OFFERLETTER = QName.createQName(ZoftModel.ZOFT_MODEL_1_0_URI, "offerLetter");
	//{http://www.zoftsolutions.com}offerLetter
	
	QName PROP_TECHNOLOGY = QName.createQName(ZoftModel.ZOFT_MODEL_1_0_URI, "technology");
	QName PROP_SALARY = QName.createQName(ZoftModel.ZOFT_MODEL_1_0_URI, "salary");

	QName ASPECT_EMPLOYEEDETAILS = QName.createQName(ZoftModel.ZOFT_MODEL_1_0_URI, "employeeDetails");
	QName PROP_EMPLOYEENAME = QName.createQName(ZoftModel.ZOFT_MODEL_1_0_URI, "employeeName");
	QName PROP_EDUCATION = QName.createQName(ZoftModel.ZOFT_MODEL_1_0_URI, "education");

}
