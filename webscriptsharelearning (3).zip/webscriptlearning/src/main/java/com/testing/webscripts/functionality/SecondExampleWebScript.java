package com.testing.webscripts.functionality;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.PropertyMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.testing.model.ZoftModel;

public class SecondExampleWebScript extends DeclarativeWebScript {
	
	 private static final Log LOGGER = LogFactory.getLog(SecondExampleWebScript.class);
	 NodeService nodeService;
	 FileFolderService fileFolderService;
	 ContentService contentService;
	 MutableAuthenticationService authenticationService;
	 AuthorityService authorityService;
	 PersonService personService;
	 SearchService searchService;
	
	 NamespaceService namespaceService;
	 //<property name="namespaceService" ref="namespaceService" />


	protected Map<String, Object> executeImpl(
            WebScriptRequest req, Status status, Cache cache) {
        Map<String, Object> model = new HashMap<String, Object>();
        
        model.put("value1","sdgdsgh");
        model.put("value2","sdgdsgh");
        
        FileInfo folderCreatedInfo = createFolder();
        model.put("value1",folderCreatedInfo.getName());
        model.put("value2",folderCreatedInfo.getNodeRef());
      /*  String url = creatContent(folderCreatedInfo.getNodeRef());
        model.put("contentURL",url);  */
        
        String specialTypeContent = spcialiseType(folderCreatedInfo.getNodeRef());
        model.put("contentURL",specialTypeContent);
        return model;
    }
   
	
	
	


	String spcialiseType(NodeRef parentNodeRef){		
		 FileInfo fileInfo = this.getFileFolderService().create(parentNodeRef, "content.txt", ZoftModel.TYPE_OFFERLETTER);
		 final Map<QName, Serializable> typeMap = new HashMap<QName, Serializable>(1);
		 typeMap.put(ZoftModel.PROP_TECHNOLOGY, "Java" );   
		 typeMap.put(ZoftModel.PROP_SALARY, 800 ); 
         nodeService.addProperties(fileInfo.getNodeRef(), typeMap); 
         
         ContentWriter contentWriter = contentService.getWriter(fileInfo.getNodeRef(), ContentModel.PROP_CONTENT, true);
	     contentWriter.setMimetype("application/text");     
	    // contentWriter.putContent(file);
	     contentWriter.putContent("We are writing the string value to this file");
	     System.out.println("Successfully created the file with the specialised type");	     
	     addAspect(fileInfo.getNodeRef());
	     return fileInfo.getName();
	     
	}

	
	void addAspect(NodeRef nodeRef){		
		   final Map<QName, Serializable> aspectMap = new HashMap<QName, Serializable>(1);
        aspectMap.put(ZoftModel.PROP_EMPLOYEENAME, "BVP" );     
        aspectMap.put(ZoftModel.PROP_EDUCATION, "BE in EC" );
        nodeService.addAspect(nodeRef , ZoftModel.ASPECT_EMPLOYEEDETAILS,aspectMap); 
	}
	
    FileInfo createFolder(){		
		NodeRef nodeRef = new NodeRef("workspace://SpacesStore/25c5982b-47c6-4002-985f-af6b5a401ec1");
		
		//NodeRef nodeRef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, "25c5982b-47c6-4002-985f-af6b5a401ec1");
		
		
		//List<FileInfo> folders = this.fileFolderService.listFolders(nodeRef);
		//FileInfo folderCreatedInfo = folders.get(0);
		//System.out.println("******************************" + folderCreatedInfo.getName() );
		FileInfo folderCreatedInfo = this.fileFolderService.create(nodeRef, "JavaFolderCreated-2", ContentModel.TYPE_FOLDER);
		System.out.println("folderCreatedInfo" + folderCreatedInfo.getNodeRef());
		System.out.println("Folder created");
		List<FileInfo> folders = this.fileFolderService.listFolders(nodeRef);
		return folderCreatedInfo;
    }
	
	
	
	String creatContent(NodeRef folderNodeRef){
		FileInfo contentInfo = this.fileFolderService.create(folderNodeRef, "testFile.txt", ContentModel.TYPE_CONTENT);
		   ContentWriter contentWriter = contentService.getWriter(contentInfo.getNodeRef(), ContentModel.PROP_CONTENT, true);
		     contentWriter.setMimetype("application/text");     
		    // contentWriter.putContent(file);
		     contentWriter.putContent("We are writing the string value to this file");
		     System.out.println("Successfully created the file");
		     return contentInfo.getName();
		     
	}
	
	
	/**
     * Get the nodeRef of companyHome
     * @return
     */
    NodeRef getCompanyHomeNodeRef(){
        NodeRef companyNoderef = null ;
        NodeRef parentRef =    nodeService.getRootNode(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
        //NodeRef companyNodeRef  = nodeService.getChildByName(parentRef, ContentModel.ASSOC_CONTAINS, "Company Home");
        QName qname = QName.createQName(NamespaceService.APP_MODEL_1_0_URI, "company_home");
        List<ChildAssociationRef> assocRefs = nodeService.getChildAssocs(parentRef, ContentModel.ASSOC_CHILDREN, qname);
        if(assocRefs != null){
            companyNoderef =  assocRefs.get(0).getChildRef(); 
        }else{
            LOGGER.error("Not able to find the Company Home nodeReference");
        }        
        return companyNoderef;
    }
    
	
    
    
    NodeRef getNodeRefPath(String path){
    	path ="app:company_home/app:dictionary/app:email_templates/cm:invite/cm:new-user-email.html.ftl";
    	NodeRef companyHome = nodeService
				.getRootNode(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		List<NodeRef> nodeRefs = searchService.selectNodes(companyHome, path,
				null, this.namespaceService, false);
		NodeRef foundNode = null;
		if (nodeRefs.size() == 1) {
			// Now localise this
			NodeRef base = nodeRefs.get(0);
			foundNode = fileFolderService.getLocalizedSibling(base);
			LOGGER.debug("Retrieved nodeRef at given path" + path);
		} else {
			LOGGER.debug("File not found in the given :" + path);
		}
		return foundNode;
	}
    
    
    
    NodeRef getFolderNodeRef() throws Exception{
        NodeRef hpiConfigNodeRef = null ; 
        ResultSet resultSet = null ;
        String xpathquery = "/app:company_home/app:dictionary/app:email_templates/cm:invite";
        try{
             resultSet  = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_XPATH, xpathquery);
            for(ResultSetRow row : resultSet)
            {
                hpiConfigNodeRef = row.getNodeRef();               
            }
            
        }catch(Exception e){
            LOGGER.error("Error in getting the nodeRef of configs", e);
            throw new Exception(e);
        }finally{
            if(resultSet != null)
            {
                resultSet.close();
            }
            if(hpiConfigNodeRef == null){
                throw new Exception(xpathquery + "folder not found");
            }
        } 
        LOGGER.debug("HPI Node Ref " + hpiConfigNodeRef);
        return hpiConfigNodeRef;
    }

    
    
    
    NodeRef getDocument( String propOneValue , String propTwoValue){
        NodeRef nodeRef = null ;  
        String contentType = "zs:offerLetter";
      //  TYPE:"zoft:customType" AND @zoft\:IM_BatchId:"batch1" AND @zoft\:IM_SysDocId:"123"        
       // String query = "TYPE:\""+appGroup+"\" AND @zoft\\:propOne:\""+batchId +"\" AND @zoft\\:propTwo:\""+docId +"\"";
          String query = "TYPE:\""+contentType+"\" AND @zs\\:technology:\""+propOneValue +"\" AND @zs\\:salary:\""+propTwoValue +"\"";
         
        LOGGER.debug("Query to get the document matching criteria " + query);   
        SearchParameters sp = new SearchParameters();
        sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
        sp.setLanguage(SearchService.LANGUAGE_FTS_ALFRESCO);
        sp.setQuery(query);
        ResultSet results = null;
        try
        {
            results = getSearchService().query(sp);
            for(ResultSetRow row : results)
            {
                nodeRef = row.getNodeRef();               
            }
            if(results!=null && results.length() > 1 ){
                LOGGER.error("Multiple documents found for this criteria , updated the metadata for the nodeRef :" + nodeRef );                
            }
        }
        finally
        {
            if(results != null)
            {
                results.close();
            }
        }         
        return nodeRef;
    }
    
    
 
    
	void addProperty(){
		
	}
	
	
	
	
	
	
	void createUser(String userName , String firstName , String lastName , String emailAddress , String instMsg , String password){		
		  NodeRef existPersonNodeRef = personService.getPerson(userName);
		if(existPersonNodeRef == null){
			PropertyMap userProperties = new PropertyMap();
	        userProperties.put(ContentModel.PROP_USERNAME, userName);
	        userProperties.put(ContentModel.PROP_FIRSTNAME, firstName);
	        userProperties.put(ContentModel.PROP_LASTNAME, lastName);
	        userProperties.put(ContentModel.PROP_EMAIL, emailAddress);
	       //userProperties.put(ContentModel.ASPECT_PERSON_DISABLED, Boolean.valueOf(personDisabled));
	        userProperties.put(ContentModel.PROP_INSTANTMSG,  instMsg);                                
	       NodeRef personNodeRef = personService.createPerson(userProperties);                                
	        //authenticationService.createAuthentication(userName, password.toCharArray());	    
	       authenticationService.createAuthentication(userName, password.toCharArray());
		   authenticationService.setAuthenticationEnabled(userName, true);
			
		}else{
			LOGGER.debug("User exists in the system");
		}		
	}
	
	
	 void createGroup(String groupName){
	        String actualName = this.authorityService.getName(AuthorityType.GROUP, groupName);
	       boolean groupExists =  this.authorityService.authorityExists(actualName);
	       if(!groupExists){
	           this.authorityService.createAuthority(AuthorityType.GROUP, groupName);
	       }else{
	           LOGGER.debug("Group already exists " + groupName);
	       }
	       
	    }
	
	
	void addUserToGroup(String userName){
		
		  Set<String> authorities =  this.authorityService.getContainedAuthorities(null , "GROUP_ALFRESCO_ADMINISTRATORS", true);
	        boolean authorityExists = authorities.contains(userName);
	        if(!authorityExists){
	        	LOGGER.debug("User does not exist" + userName);             	
              authorityService.addAuthority("GROUP_ALFRESCO_ADMINISTRATORS", userName);
	        }else{
	        	LOGGER.debug("Already the group belongs to the ALFRESCO_ADMINISTRATORS group" + userName);
	        }
	}
	
    
    
	public NodeService getNodeService() {
		return nodeService;
	}


	public FileFolderService getFileFolderService() {
		return fileFolderService;
	}


	public ContentService getContentService() {
		return contentService;
	}


	public AuthenticationService getAuthenticationService() {
		return authenticationService;
	}


	public AuthorityService getAuthorityService() {
		return authorityService;
	}


	public PersonService getPersonService() {
		return personService;
	}


	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}

	

	

	public void setAuthenticationService(MutableAuthenticationService authenticationService) {
		this.authenticationService = authenticationService;
	}


	public void setAuthorityService(AuthorityService authorityService) {
		this.authorityService = authorityService;
	}


	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
	
	public SearchService getSearchService() {
		return searchService;
	}


	public void setSearchService(SearchService searchService) {
		this.searchService = searchService;
	}

	public NamespaceService getNamespaceService() {
		return namespaceService;
	}

	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}


}


